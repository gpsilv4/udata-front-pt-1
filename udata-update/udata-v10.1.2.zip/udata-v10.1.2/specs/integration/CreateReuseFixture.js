reuseName = "Test reuse " + Math.random().toString(36).substring(7)
reuseDescription = reuseName + " description"
reuseUrl = "http://example.org/" + Math.random().toString(36).substring(7)
