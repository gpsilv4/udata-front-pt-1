homeLink: ".navbar-brand",
nextLink: "button.pointer:last-child",
contributeLink: 'a[title="Contribute!"]',
firstResultLink: '.search-results .dataset-result:first-child .result-title',
menuFromFrontLink: '.login button',
adminDashboardLink: '.sidebar-menu li:first-child a',
adminFromFrontMenuLink: '.login a[href$="/admin/"]',

// Warning: that link is switching the language to French.
homeFromAdminLink: ".main-header a.logo",
