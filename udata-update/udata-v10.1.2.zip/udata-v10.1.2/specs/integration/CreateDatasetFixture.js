datasetName = "Test dataset " + Math.random().toString(36).substring(7)
datasetDescription = datasetName + " description"
