createCommunityResourceLink: ".community_container .resources-list .add:not(.new-discussion)",
viewOnSiteLink: ".box-body component a.btn-flat",
lastCommunityResourceResult: ".community_container .resources-list .list-group-item:last-of-type .list-group-item-heading.ellipsis span",
