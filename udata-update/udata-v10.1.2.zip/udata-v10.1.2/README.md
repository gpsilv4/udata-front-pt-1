<p align="center"><img src="https://i.imgur.com/rlRox1c.png"></p>

udata
=====

Customizable and skinnable social platform dedicated to (open) data.

The [full documentation][readthedocs-url] is hosted on Read the Docs.

udata is maintained by [data.gouv.fr](https://data.gouv.fr/), the
French public agency in charge of open data. data.gouv.fr is responsible
for publishing udata's roadmap and for building consensus around it.

It is collectively taken care of by members of the
[OpenDataTeam](https://github.com/opendatateam).

[readthedocs-url]: https://udata.readthedocs.io/en/stable/
