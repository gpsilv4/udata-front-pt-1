export default {
    props: {
        details: Object
    }
};
