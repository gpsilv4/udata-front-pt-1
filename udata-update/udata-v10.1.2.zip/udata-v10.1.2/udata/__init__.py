#!/usr/bin/env python

"""
udata
"""

__version__ = "10.1.2"
__description__ = "Open data portal"
